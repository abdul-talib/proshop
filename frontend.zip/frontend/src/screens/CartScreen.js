import React from 'react'

const CartScreen = () => {
  return  <div>Cart</div>
  }

export default CartScreen
